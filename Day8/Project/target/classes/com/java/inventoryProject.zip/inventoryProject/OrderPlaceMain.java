package com.java.inventoryProject;

import java.sql.SQLException;
import java.util.Scanner;

public class OrderPlaceMain {
	
	public static void placeOrderMain() throws ClassNotFoundException, SQLException
	{
		Scanner sc = new Scanner(System.in);
		String StockId; int qty;
		System.out.println("enter stockId to order");
		StockId = sc.next();
		System.out.println("Enter Quantity of an Item");
		qty = sc.nextInt();
		OrdersDAO dao = new OrdersDaoImpl();
		System.out.println(dao.placeOrder(StockId, qty));
		
	}
	
	public static void main(String[] args) {
		
		try {
			placeOrderMain();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
