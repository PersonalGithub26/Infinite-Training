package com.jsf.complant;

import java.util.List;

public interface ComplaintEDAO {

	String AddComplaint();
	List<ComplaintE> ShowAllComplaint();
}
