package com.java.jsfHib;

import java.util.List;

public interface PolicyDAO {
	
	 List<Policy> showPolicyNamesByCompId();
}
