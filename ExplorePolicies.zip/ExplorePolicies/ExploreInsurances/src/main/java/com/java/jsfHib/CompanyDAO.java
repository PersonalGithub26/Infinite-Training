package com.java.jsfHib;

import java.util.List;

public interface CompanyDAO {
	
	List<Company> showCompanyNames();
}