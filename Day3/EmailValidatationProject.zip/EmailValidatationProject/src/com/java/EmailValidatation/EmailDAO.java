package com.java.EmailValidatation;

public interface EmailDAO {
	
	public String showValidEmailDao();
	

}
