package com.java.employeeLeave;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LeaveDaoImp implements LeaveDAO {
	static List<Leave1> LeaveList;
	static Leave1 leave;


	static 
	{
		LeaveList = new ArrayList<Leave1>();
		leave = new Leave1();
	}


	@Override
	public String addLeave(Leave1 leave) 
	{
		long days = leave.getLeaveEndDate().getTime() - leave.getLeaveStartDate().getTime();	
		int Days = (int) (days / (1000 * 60 * 60 * 24)+1);
		System.out.println(Days);
		leave.setNoOfDays(Days);
		leave.setLeaveAppliedOn(new Date());
		LeaveList.add(leave);
		return "-----Leave added Successfully-----";
	}


	@Override
	public List<Leave1> showLeaves() 
	{
		return LeaveList;
	}












}
