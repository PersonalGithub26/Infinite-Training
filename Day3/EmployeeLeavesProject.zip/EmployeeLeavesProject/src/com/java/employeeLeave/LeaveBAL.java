package com.java.employeeLeave;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class LeaveBAL {
	static LeaveDAO ld;
	static StringBuilder sb;
	static SimpleDateFormat sd;

	static 
	{
		ld = new LeaveDaoImp(); 
		sb = new StringBuilder();	
		sd=new SimpleDateFormat();

	}

	public boolean doValid(Leave1 leave) throws ParseException
	{

		boolean isValid = true;
				

		if(leave.getLeaveStartDate() != null)
		{
			String yesterdayDate = null;
			Date date = new Date();
			Calendar c = Calendar.getInstance();
			c.setTime(date);
			c.add(Calendar.DATE, -1);
			yesterdayDate = c.toString();
			
			//if(sd.format(leave.getLeaveStartDate()).equals(sd.parse(yesterdayDate)))
			if (leave.getLeaveStartDate().before(new Date()))
			{
				sb.append("Leave Start date cannot be yeasterday's date....");
				isValid = false;
			}
			if(leave.getLeaveEndDate().before(new Date()))
			{


				sb.append("Leave end date cannot be yestarday's date");
				isValid = false;
			}

			
		}
		if (leave.getLeaveStartDate().after(leave.getLeaveEndDate()))
		{
			sb.append("Leave start date cannot be greater than leave end date");
			isValid = false;
		}
		return isValid;

	}

	public String addEmployeeBal(Leave1 leave) throws LeaveExceptionClass, ParseException
	{
		if(doValid(leave) == false)
		{
			throw new LeaveExceptionClass(sb.toString());
		}

		return ld.addLeave(leave);
	}

	public List<Leave1> showLeavesBal()
	{
		return ld.showLeaves();
	}


}
