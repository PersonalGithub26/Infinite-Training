package com.java.employeeLeave;

import java.util.Date;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MainLeave {
	static Leave1 leave;
	static LeaveBAL lb;
	static Scanner sc;
	
	static
	{
		lb = new LeaveBAL();
		sc = new Scanner(System.in);
		leave = new Leave1();
	}
	
	public static void addLeaveMain() throws  LeaveExceptionClass, ParseException 
	{
		
		SimpleDateFormat sd = new SimpleDateFormat("dd-MM-yyyy");
		
		System.out.println("Enter Employee Id");
		
		leave.setEmpId(sc.nextInt());
		System.out.println("Enter leave start date in dd-MM-YYYY format");
		String leaveStartDate = sc.next();
		Date startDate = sd.parse(leaveStartDate);
		leave.setLeaveStartDate(startDate);
		System.out.println("Enter leave end date in dd-MM-YYYY format");
		String leaveEndDate = sc.next();
		Date endDate = sd.parse(leaveEndDate);
		leave.setLeaveEndDate(endDate);
		System.out.println("Enter Leave reason");
		leave.setLeaveReason(sc.next());
		System.out.println("Enter leave type 'EL, PL, ML'");
		
		 leave.setLeaveType(LeaveType.valueOf(sc.next()));
		
		System.out.println(lb.addEmployeeBal(leave));
		
		
		
	}
	public static void showLeavesMain()
	{
		List<Leave1> leaves = lb.showLeavesBal();
		for (Leave1 leavess : leaves) 
		{
			System.out.println(leavess);
		}
	}
	
	
	public static void main(String[] args) {
		int choice;
		do{
			System.out.println(" O P T I O N S");
			System.out.println("================");
			System.out.println("1. Add new leave");
			System.out.println("2. Show total leaves");
			choice = sc.nextInt();
			switch(choice)
			{
			case 1:
				try {
					addLeaveMain();
					
				} catch (ParseException | LeaveExceptionClass e) {
					
					System.err.println(e.getMessage());
					
					
				}
				break;
			case 2:
				showLeavesMain();
				break;
			}
			
		}while(true);
	}

}
