package com.java.employeeLeave;

public class LeaveExceptionClass extends Exception
{
	public LeaveExceptionClass(String error)
	{
		super(error);
	}
	
	public LeaveExceptionClass(){}

}
