package com.java.employeeLeave;

public enum LeaveType {
	
	EL, PL, ML

}
