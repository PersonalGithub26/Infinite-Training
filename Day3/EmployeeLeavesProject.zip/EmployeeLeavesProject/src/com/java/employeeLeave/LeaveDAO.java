package com.java.employeeLeave;

import java.util.Date;
import java.util.List;

public interface LeaveDAO {
	
	String addLeave(Leave1 leave);
	List<Leave1> showLeaves();
	

}
