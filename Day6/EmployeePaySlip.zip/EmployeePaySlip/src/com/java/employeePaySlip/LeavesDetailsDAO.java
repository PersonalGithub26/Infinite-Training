package com.java.employeePaySlip;

public interface LeavesDetailsDAO {
	
	String applyLeave(LeavesDetails leaveDetails); 

}
