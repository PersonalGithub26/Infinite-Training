package com.jsf.lib;

import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;

import org.hibernate.HibernateException;

@ManagedBean(name = "Dao")
@SessionScoped
public class LibraryDaoImp implements LibraryDAO {
	private String searchType;
	private String searchValue;

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(String searchValue) {
		this.searchValue = searchValue;
	}

	@Override
	public List<Books> searchBooks() throws HibernateException {

		if (searchType == null || searchValue == null) {
			return null;
		}
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Books.class);
		if (searchType.equals("id")) {
			cr.add(Restrictions.eq("id", Integer.parseInt(searchValue)));
		} else if (searchType.equals("bookname")) {
			cr.add(Restrictions.eq("name", searchValue));
		} else if (searchType.equals("authorname")) {
			cr.add(Restrictions.eq("author", searchValue));
		} else if (searchType.equals("dept")) {
			cr.add(Restrictions.eq("dept", searchValue));
		}else if (searchType.equals("all")) {
			cr.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		}
		List<Books> booksList = cr.list();
		session.close();
		return booksList;
	}
		
			
		  

}
