package com.cmsJsf;

import java.util.List;

public interface RestaurantDAO {

	 List<Restaurant> showRestaurants();
	 List<String> showRestaurantNames();
	 
}
