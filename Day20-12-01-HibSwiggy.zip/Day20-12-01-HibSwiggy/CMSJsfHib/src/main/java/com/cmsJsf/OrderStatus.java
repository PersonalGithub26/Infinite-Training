package com.cmsJsf;

public enum OrderStatus {

	ACCEPTED, DENIED, PENDING
}
