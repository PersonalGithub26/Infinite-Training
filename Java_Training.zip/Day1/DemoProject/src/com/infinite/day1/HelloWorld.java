package com.infinite.day1;

public class HelloWorld {
	
	public static void main(String[] args) {
		System.out.println("Hello World...!");
		
		int i = 12;
	i = i++ + i-- + ++i - i-- +--i;
	System.out.println(i);
	}

}
