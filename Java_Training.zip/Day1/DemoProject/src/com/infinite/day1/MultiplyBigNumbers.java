package com.infinite.day1;

public class MultiplyBigNumbers {
	public static void main(String[] args) {
		String s1 = "12345";
		String s2 = "12345";
		int a = 1;
		int b = 1;
		
		for (int i = s1.length() - 1; i > 0; i--) 
		{
			for (int j = s2.length() - 1; j >= 0; j--) 
			{
				a = s1.charAt(i) - '0';
			}
		}
		System.out.println(a);
	}

}
