package com.infinite.day1;

public class ArrayDemo1 {
	public void show()
	{
		int[] a = new int[] {1,3,5,3,463,45};
		for (int i : a) {
			System.out.print(i+" ");
			
		}
	}
	public static void main(String[] args) {
		new ArrayDemo1().show();
	}

}
