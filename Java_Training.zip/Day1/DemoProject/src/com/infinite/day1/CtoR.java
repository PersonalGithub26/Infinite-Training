package com.infinite.day1;

public class CtoR { 
	public void CentToRa(int b)
	{
		System.out.println((b)*3.14/10);
	}
	public static void main(String[] args) {
		int b= 90;
		new CtoR().CentToRa(b);
	}

}
