package com.infinite.day1;

public class Demo {
	
	public void sayHello()
	{
		System.out.println("Wecome to java programme");
	}
	void company()
	{
		System.out.println("From infinite solutions..");
	}
	
	private void location()
	{
		System.out.println("From vishakapatanam");
	}

}
