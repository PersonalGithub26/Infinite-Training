package com.infinite.day1;

public class StrEx {
	public static void main(String[] args) {
		String str = "Hello";
		String str2 = "World";
		str.concat(str2);
		System.out.println();
	}

}
