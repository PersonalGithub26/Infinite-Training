package com.java.day2;

public class DemoAll {
	private int i;
	private String name;
	
	

}
