package com.java.day2;

public enum OrderStatus 
{
	
	ACCEPTED, REJECTED, PENDING
}
