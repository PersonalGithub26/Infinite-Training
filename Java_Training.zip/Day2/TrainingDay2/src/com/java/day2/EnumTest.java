package com.java.day2;

public class EnumTest {
	public static void main(String[] args) {
		WeekDays wd = WeekDays.MONDAY;
		System.out.println(wd);
		
		
	}

}
