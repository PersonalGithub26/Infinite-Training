package com.java.sup;

public class Chandu extends Employee{

	public Chandu(int empId, String empName, double salary) {
		super(empId, empName, salary);
		
	}

}
