package com.java.sup;

public class SupEx {
	public static void main(String[] args) {
		Second s = new Second();
		s.show();
	}

}
