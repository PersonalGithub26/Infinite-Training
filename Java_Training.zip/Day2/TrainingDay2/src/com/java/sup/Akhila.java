package com.java.sup;

public class Akhila extends Employee{

	public Akhila(int empId, String empName, double salary) {
		super(empId, empName, salary);
		
		
	}

}
