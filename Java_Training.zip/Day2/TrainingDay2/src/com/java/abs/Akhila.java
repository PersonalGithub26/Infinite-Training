package com.java.abs;

public class Akhila extends Training{

	@Override
	public void name() {
System.out.println("Name is pntam");		
	}

	@Override
	public void phone() {
System.out.println("phone is 248r928");		
	}
	

}
