package com.java.abs;

public class AbsEx {
	
	

}
