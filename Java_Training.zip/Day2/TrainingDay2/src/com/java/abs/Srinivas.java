package com.java.abs;

public class Srinivas extends Training{

	@Override
	public void name() {
System.out.println("name is chandu");		
	}

	@Override
	public void phone() {
System.out.println("phoen is gqer196");		
	}

}
