package com.java.abs;

public class Chandu extends Training{

	@Override
	public void name()
	{
		System.out.println("Chandu is the  name");
	}

	@Override
	public void phone() {
		
		System.out.println("0296228r is the pone" );
	}
}
