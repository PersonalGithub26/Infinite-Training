package com. java.Collections;

import java.util.Scanner;

public class Scan2 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a,b,c;
		System.out.println("ENTER NUMBERS");
		a = sc.nextInt();
		b = sc.nextInt();
		c = a+b;
		System.out.println(c);
	}

}
