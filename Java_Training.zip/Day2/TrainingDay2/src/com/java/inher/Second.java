package com.java.inher;

public class Second extends First{
	public void display()
	{
		System.out.println("From second class");
	}

}
