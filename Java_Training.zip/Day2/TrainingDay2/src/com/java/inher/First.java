package com.java.inher;

public class First {
	
	public void show()
	{
		System.out.println("show method from parent");
	}

}
