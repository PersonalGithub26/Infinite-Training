package com.java.inher;

public class TestC {
	public static void main(String[] args) {
		C2 c = new C2();
		
	}

}
