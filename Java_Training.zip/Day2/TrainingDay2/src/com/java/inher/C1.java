package com.java.inher;

public class C1 {
	public C1()
	{
		System.out.println("base class ontructor");
	}

}
