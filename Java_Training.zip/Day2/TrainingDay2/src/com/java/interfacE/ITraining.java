package com.java.interfacE;

public interface ITraining {
	
	void name();
	void stream();

}
