package com.java.interfacE;

public interface IOne1 {
	
	default void show()
	{
		System.out.println("IOne show");
	}

}
