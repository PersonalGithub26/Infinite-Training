package com.java.interfacE;

public interface IOne {
	void name();
	

}
