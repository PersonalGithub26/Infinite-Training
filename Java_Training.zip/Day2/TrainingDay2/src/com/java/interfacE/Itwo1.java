package com.java.interfacE;

public interface Itwo1 {
	default void show()
	{
		System.out.println("ITwo Show");
	}

}
