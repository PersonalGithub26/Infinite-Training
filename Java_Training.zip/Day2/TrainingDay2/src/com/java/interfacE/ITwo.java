package com.java.interfacE;

public interface ITwo {
	void sream();

}
