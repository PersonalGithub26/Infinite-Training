package com.java.interfacE;

public class Akhil implements ITraining{

	@Override
	public void name() {
		System.out.println("Akhil name");
	}

	@Override
	public void stream() {
		System.out.println("cse");
	}
	

}
