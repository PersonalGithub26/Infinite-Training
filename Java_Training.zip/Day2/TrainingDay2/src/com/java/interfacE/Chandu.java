package com.java.interfacE;

public class Chandu implements ITraining {

	@Override
	public void name() {
		System.out.println("chandu name");
	}

	@Override
	public void stream() {
		System.out.println("Ece");
		
	}

}
