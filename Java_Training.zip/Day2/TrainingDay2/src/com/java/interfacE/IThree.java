package com.java.interfacE;

public interface IThree {
	default void show()
	{
		System.out.println("IThree show");
	}

}
