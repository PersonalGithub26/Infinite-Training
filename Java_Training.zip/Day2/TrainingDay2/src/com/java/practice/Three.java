package com.java.practice;

public interface Three {
	default void name()
	{
		System.out.println("three");
	}

}
