package com.java.practice;

public interface One {
	 default void name()
	 {
		 System.out.println("One");
	 }
	

}
