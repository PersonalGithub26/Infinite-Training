package com.java.practice;

public interface Two {
	default void name()
	{
		System.out.println("two");
	}
}
