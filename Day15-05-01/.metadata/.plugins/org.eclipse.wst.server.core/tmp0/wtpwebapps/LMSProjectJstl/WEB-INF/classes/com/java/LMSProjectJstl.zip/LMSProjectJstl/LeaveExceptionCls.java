package com.java.LMSProjectJstl;

public class LeaveExceptionCls extends Exception{
	public LeaveExceptionCls(String error)
	{
		super(error);
	}
	
	public LeaveExceptionCls(){}

	

}
