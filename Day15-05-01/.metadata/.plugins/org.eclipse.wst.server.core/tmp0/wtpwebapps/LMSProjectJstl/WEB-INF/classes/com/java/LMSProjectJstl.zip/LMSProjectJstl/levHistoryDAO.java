package com.java.LMSProjectJstl;

public interface levHistoryDAO {
	
	public String ApplyLeave(levHistory lev) throws LeaveExceptionCls, Exception;

}
