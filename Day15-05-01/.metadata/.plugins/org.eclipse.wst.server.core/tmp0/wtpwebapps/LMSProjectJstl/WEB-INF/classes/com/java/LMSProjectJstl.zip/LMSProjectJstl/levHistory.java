package com.java.LMSProjectJstl;

import java.util.Date;

public class levHistory {
	
//	LEAVE_ID INT PRIMARY KEY AUTO_INCREMENT,
//	LEAVE_NO_OF_DAYS INT,
//	LEAVE_MNGR_COMMENTS CHAR(200),
//	EMP_ID INT,
//	LEAVE_START_DATE DATE NOT NULL, 
//	LEAVE_END_DATE DATE NOT NULL,
//	LEAVE_TYPE ENUM ('EL' ) DEFAULT 'EL',
//	LEAVE_STATUS ENUM ('PENDING','APPROVED','DENIED') DEFAULT 'PENDING',
//	LEAVE_REASON  CHAR(50) NOT NULL,
	
	private int leaveId;
	private int NoOfDays;
	private String levMngCmts;
	private int empId;
	private Date StDate;
	private Date EndDate;
	private leaveTyp leaveTyp;
	private levStatus status;
	private String levReason;
	public int getLeaveId() {
		return leaveId;
	}
	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}
	public int getNoOfDays() {
		return NoOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		NoOfDays = noOfDays;
	}
	public String getLevMngCmts() {
		return levMngCmts;
	}
	public void setLevMngCmts(String levMngCmts) {
		this.levMngCmts = levMngCmts;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public Date getStDate() {
		return StDate;
	}
	public void setStDate(Date stDate) {
		StDate = stDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public leaveTyp getLeaveTyp() {
		return leaveTyp;
	}
	public void setLeaveTyp(leaveTyp leaveTyp) {
		this.leaveTyp = leaveTyp;
	}
	public levStatus getStatus() {
		return status;
	}
	public void setStatus(levStatus status) {
		this.status = status;
	}
	public String getLevReason() {
		return levReason;
	}
	public void setLevReason(String levReason) {
		this.levReason = levReason;
	}
	public levHistory(int leaveId, int noOfDays, String levMngCmts, int empId, Date stDate, Date endDate,
			com.java.LMSProjectJstl.leaveTyp leaveTyp, levStatus status, String levReason) {
		this.leaveId = leaveId;
		NoOfDays = noOfDays;
		this.levMngCmts = levMngCmts;
		this.empId = empId;
		StDate = stDate;
		EndDate = endDate;
		this.leaveTyp = leaveTyp;
		this.status = status;
		this.levReason = levReason;
	}
	public levHistory() {
		
	}
	@Override
	public String toString() {
		return "levHistory [leaveId=" + leaveId + ", NoOfDays=" + NoOfDays + ", levMngCmts=" + levMngCmts + ", empId="
				+ empId + ", StDate=" + StDate + ", EndDate=" + EndDate + ", leaveTyp=" + leaveTyp + ", status="
				+ status + ", levReason=" + levReason + "]";
	}
	
	
	
	

}
