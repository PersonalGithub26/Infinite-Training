package com.java.LMSProjectJstl;

public enum leaveTyp {
	EL
}
