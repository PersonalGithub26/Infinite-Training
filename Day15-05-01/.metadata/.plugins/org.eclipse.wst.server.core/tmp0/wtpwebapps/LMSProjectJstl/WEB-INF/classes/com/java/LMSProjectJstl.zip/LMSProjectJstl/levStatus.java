package com.java.LMSProjectJstl;

public enum levStatus {
	
	PENDING, APPROVED, DENIED

}
